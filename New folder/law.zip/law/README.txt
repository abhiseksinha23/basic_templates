THEME: Law - Free Bootstrap 4 Theme
AUTHOR: uiCookies.com
LICENSE: Under Creative Commons 3.0 (uiCookies.com/license)
AUTHOR URI: https://uiCookies.com/
Twitter: https://twitter.com/probootstrap
Facebook: https://facebook.com/probootstrap


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Demo Images
https://unsplash.com

WayPoints
http://imakewebthings.com/waypoints/

Animate.css
https://daneden.github.io/animate.css/

Slick Slider
https://kenwheeler.github.io/slick/

FontAwesome
https://fontawesome.com/

Flaticon
https://flaticon

Ionicons
https://ionicons.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/